# NGINA OASEAS Habitat Companion — Linux Mint Deployment

**Supports: Linux Mint 21.x / 22.x — Cinnamon · MATE · Xfce**

NGINA runs as a local AI habitat companion with:
- **Applications Menu** launcher (Menu → Science → NGINA)
- **System tray applet** via `python3-xapp` — works on all three Mint DEs
- **Nemo right-click scripts** — Start, Sensor Readings, Chat with NGINA
- **`yad` GUI dialogs** — Mint-native, no zenity required
- **DE-aware editor/terminal** selection in `ngina-ctl`
- **Autostart** at login via XDG (supports GNOME, MATE, and Xfce flags)
- **User-local install** — everything in `~/.local/`, one `sudo` for `apt`

---

## Install

```bash
bash install-mint.sh
```

The installer detects your desktop environment automatically (Cinnamon / MATE / Xfce), installs the right packages, shows `yad` GUI dialogs for setup, and adds NGINA to your applications menu and login autostart.

---

## Mint Desktop Environment Notes

### Cinnamon
- Tray icon appears in the **system tray** (bottom-right panel area)
- Uses `python3-xapp` `StatusIcon` — native Mint integration
- Right-click the Cinnamon taskbar to add a **Notification Area** if the icon is missing
- `xed` is the default config editor

### MATE
- Tray icon appears in the **Notification Area** panel applet
- If missing: right-click panel → **Add to Panel → Notification Area**
- `pluma` is the default config editor

### Xfce (Linux Mint Xfce edition)
- Tray icon appears in the **Status Tray Plugin** or **Notification Area**
- If missing: right-click panel → **Panel → Add New Items → Status Tray Plugin**
- `mousepad` is the default config editor

---

## Files installed

```
~/.local/ngina/               Main application
    firmware/                 Teksta puppy hardware layer
    orchestration/            NGINA AI brain (four paradigms)
    dashboard/index.html      Web UI
    server.py                 Local Flask server (loopback only)
    tray/ngina_tray.py        Tray applet (python3-xapp)
    launch.sh                 Session start script
    venv/                     Python virtualenv

~/.config/ngina/ngina.env     Configuration (API key, port, DE)
~/.config/autostart/          Login autostart entries
~/.local/share/applications/  Apps menu .desktop
~/.local/share/icons/ngina/   Triskelion SVG icon
~/.local/share/nemo/scripts/  Nemo file manager scripts
~/.local/share/ngina/logs/    Log files
~/.local/bin/ngina-ctl        CLI management tool
```

---

## ngina-ctl

```bash
ngina-ctl start                # Start NGINA + open browser
ngina-ctl stop                 # Stop NGINA
ngina-ctl restart              # Restart
ngina-ctl status               # Status + health check
ngina-ctl open                 # Open dashboard in browser

ngina-ctl tray start           # Start tray applet
ngina-ctl tray stop            # Stop tray applet
ngina-ctl tray restart         # Restart tray applet

ngina-ctl config               # Edit config in GUI editor
ngina-ctl set-apikey           # Set Anthropic API key interactively
ngina-ctl update               # Upgrade Python dependencies

ngina-ctl logs [N]             # Tail last N log lines
ngina-ctl logs-gui             # Open log in a terminal window
ngina-ctl sensor-test          # Print live sensor readings
ngina-ctl chat "Hello"         # Talk to NGINA from terminal
ngina-ctl patrol               # Trigger environmental patrol
ngina-ctl briefing             # Request morning briefing

ngina-ctl autostart enable     # Start NGINA at desktop login
ngina-ctl autostart disable    # Disable autostart
ngina-ctl de-info              # Show DE + tray backend diagnostics
ngina-ctl uninstall            # Remove NGINA from desktop
```

---

## Nemo File Manager Scripts

After install, right-click anywhere in Nemo → **Scripts → NGINA**:

| Script | Action |
|---|---|
| `NGINA - Start` | Start NGINA and open dashboard |
| `NGINA - Sensor Readings` | Show live sensor data in a yad dialog |
| `NGINA - Chat` | Send a message to NGINA via yad input |

---

## Configuration

```bash
ngina-ctl config
# or: nano ~/.config/ngina/ngina.env
```

```env
# Anthropic API key (https://console.anthropic.com)
ANTHROPIC_API_KEY=sk-ant-...

# 0 = live Claude responses, 1 = simulated (no key needed)
NGINA_SIMULATE_API=0

# Auto-open browser when NGINA starts
NGINA_OPEN_BROWSER=1

# Local port (change if 8765 is taken)
NGINA_PORT=8765

# Hardware: 1 = real Teksta puppy (Raspberry Pi), 0 = simulation
NGINA_HARDWARE=0

# Auto-detected by installer — used for DE-aware editor/terminal selection
NGINA_DE=cinnamon
```

Restart after any change: `ngina-ctl restart`

---

## API

Same REST API as the server and Ubuntu Desktop editions:

```bash
curl http://127.0.0.1:8765/api/health
curl http://127.0.0.1:8765/api/status
curl -X POST http://127.0.0.1:8765/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Good morning NGINA","crew":"akinyi"}'
curl -X POST http://127.0.0.1:8765/api/puppy/patrol
```

---

## Differences from Ubuntu Desktop Edition

| Feature | Ubuntu Desktop | Linux Mint |
|---|---|---|
| GUI dialogs | zenity | **yad** (Mint default) |
| Tray backend | AppIndicator3 (GNOME) | **python3-xapp** (all Mint DEs) |
| Text editor | gedit / xed | **xed / pluma / mousepad** (DE-aware) |
| File manager scripts | Nautilus scripts | **Nemo scripts** |
| Autostart flags | X-GNOME only | **X-GNOME + X-MATE** |
| DE detection | GNOME assumed | **Cinnamon / MATE / Xfce detected** |
| Package: dialogs | zenity | yad |
| Package: tray | gir1.2-appindicator3 | **python3-xapp xapp** |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `ngina-ctl` not found | `source ~/.bashrc` or open new terminal |
| Tray icon not visible (Cinnamon) | Right-click panel → add Notification Area |
| Tray icon not visible (MATE) | Right-click panel → Add to Panel → Notification Area |
| Tray icon not visible (Xfce) | Right-click panel → Add New Items → Status Tray Plugin |
| Nemo scripts missing | Run `install-mint.sh` again; check `~/.local/share/nemo/scripts/` |
| `yad` not found | `sudo apt install yad` |
| `python3-xapp` missing | `sudo apt install python3-xapp xapp` |
| Port 8765 in use | Change `NGINA_PORT` in config; `ngina-ctl restart` |
| Wrong editor opens | `ngina-ctl de-info` — update `NGINA_DE` in config if wrong |
| API key not working | No quotes around key in `ngina.env`; `ngina-ctl set-apikey` |

---

## Deployment comparison

| | Ubuntu Server | Ubuntu Desktop | Linux Mint |
|---|---|---|---|
| Install path | `/opt/ngina` | `~/.local/ngina` | `~/.local/ngina` |
| Web server | Gunicorn + nginx | Flask (loopback) | Flask (loopback) |
| Process manager | systemd | PID file | PID file |
| Tray | — | AppIndicator3 | **python3-xapp** |
| Dialogs | — | zenity | **yad** |
| File manager | — | Nautilus | **Nemo** |
| DE support | — | GNOME | **Cinnamon/MATE/Xfce** |
