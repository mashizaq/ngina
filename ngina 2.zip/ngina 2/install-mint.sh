#!/usr/bin/env bash
# =============================================================================
#  NGINA OASEAS Habitat Companion — Linux Mint Installer
#  Supports: Linux Mint 21.x / 22.x
#  Desktop environments: Cinnamon · MATE · Xfce
#
#  Run as your normal user (no sudo required except for apt):
#    bash install-mint.sh
# =============================================================================
set -euo pipefail

# ── Colour helpers ─────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}[INFO]${RESET}  $*"; }
success() { echo -e "${GREEN}[OK]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $*"; }
error()   { echo -e "${RED}[ERROR]${RESET} $*"; exit 1; }

# ── Detect desktop environment ────────────────────────────────────────────────
detect_de() {
  local de="${XDG_CURRENT_DESKTOP:-${DESKTOP_SESSION:-unknown}}"
  de="${de,,}"   # lowercase
  if   [[ "$de" == *cinnamon* ]]; then echo "cinnamon"
  elif [[ "$de" == *mate*     ]]; then echo "mate"
  elif [[ "$de" == *xfce*     ]]; then echo "xfce"
  elif [[ "$de" == *kde*      ]]; then echo "kde"
  else                                  echo "unknown"
  fi
}
DE=$(detect_de)
info "Detected desktop: ${DE}"

# ── Detect Mint version ───────────────────────────────────────────────────────
MINT_VER="unknown"
[[ -f /etc/linuxmint/info ]] && \
  MINT_VER=$(grep "^RELEASE=" /etc/linuxmint/info | cut -d= -f2 | tr -d '"')
info "Linux Mint version: ${MINT_VER}"

# ── GUI dialog helpers (yad → zenity → terminal fallback) ─────────────────────
GUI_TOOL=""
command -v yad    &>/dev/null && GUI_TOOL="yad"
command -v zenity &>/dev/null && [[ -z "$GUI_TOOL" ]] && GUI_TOOL="zenity"

gui_info() {
  case "$GUI_TOOL" in
    yad)    yad --info --title="NGINA Installer" --text="$*" --width=400 \
                --button="OK:0" 2>/dev/null || true ;;
    zenity) zenity --info --title="NGINA Installer" --text="$*" --width=400 2>/dev/null || true ;;
    *)      info "$*" ;;
  esac
}
gui_question() {   # returns 0=yes 1=no
  case "$GUI_TOOL" in
    yad)    yad --question --title="NGINA Installer" --text="$*" --width=400 \
                --button="Yes:0" --button="No:1" 2>/dev/null ;;
    zenity) zenity --question --title="NGINA Installer" --text="$*" --width=400 2>/dev/null ;;
    *)      read -rp "$* [y/N]: " yn; [[ "${yn,,}" == "y" ]] ;;
  esac
}
gui_password() {
  case "$GUI_TOOL" in
    yad)    yad --entry --title="NGINA — API Key" \
                --text="Enter your Anthropic API key\n(leave blank to use simulation mode):" \
                --hide-text --width=460 2>/dev/null || echo "" ;;
    zenity) zenity --password --title="NGINA — API Key" 2>/dev/null || echo "" ;;
    *)      read -rsp "Anthropic API Key (hidden, leave blank to skip): " val; echo; echo "${val:-}" ;;
  esac
}
gui_notify() {     # title body
  command -v notify-send &>/dev/null && \
    notify-send "$1" "$2" --icon=dialog-information --app-name=NGINA \
                          --expire-time=5000 2>/dev/null || true
}

banner() {
  echo -e "${BOLD}${CYAN}"
  cat <<'EOF'
╔══════════════════════════════════════════════════════════════╗
║   NGINA — OASEAS Habitat AI Orchestrator                     ║
║   Linux Mint Installer v2.1.0                                ║
║   Cinnamon · MATE · Xfce                                     ║
║   Triskelion: Life Support · Resource Mgmt · Ethics          ║
╚══════════════════════════════════════════════════════════════╝
EOF
  echo -e "${RESET}"
}

# ── Paths ─────────────────────────────────────────────────────────────────────
NGINA_HOME="${HOME}/.local/ngina"
VENV_DIR="${NGINA_HOME}/venv"
CONFIG_DIR="${HOME}/.config/ngina"
LOG_DIR="${HOME}/.local/share/ngina/logs"
DESKTOP_DIR="${HOME}/.local/share/applications"
AUTOSTART_DIR="${HOME}/.config/autostart"
BIN_DIR="${HOME}/.local/bin"
ICON_DIR="${HOME}/.local/share/icons/ngina"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NGINA_PORT="8765"

# ── Privilege check ───────────────────────────────────────────────────────────
[[ $EUID -eq 0 ]] && error "Run as your normal user, not root: bash install-mint.sh"

banner

# ── 1. System packages ────────────────────────────────────────────────────────
info "Installing system packages (requires sudo for apt)..."
sudo apt-get update -qq

# Base packages
PKGS=(
  python3 python3-pip python3-venv python3-dev
  python3-gi python3-gi-cairo
  gir1.2-gtk-3.0
  espeak espeak-ng
  portaudio19-dev libportaudio2
  alsa-utils
  i2c-tools
  libnotify-bin
  xdg-utils
  curl wget
)

# DE-specific tray support
case "$DE" in
  cinnamon|mate|xfce|unknown)
    # python3-xapp works across all Mint DEs; fall back to StatusIcon
    PKGS+=(python3-xapp)
    ;;
esac

# yad for GUI dialogs (Mint doesn't ship zenity by default)
PKGS+=(yad)

# MATE-specific
[[ "$DE" == "mate" ]] && PKGS+=(mate-notification-daemon)

# Xfce-specific
[[ "$DE" == "xfce" ]] && PKGS+=(xfce4-notifyd)

sudo apt-get install -y -qq "${PKGS[@]}" > /dev/null
success "System packages installed."

# ── 2. Python version check ───────────────────────────────────────────────────
PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
info "Python ${PY_VER} detected."
python3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" || {
  warn "Python 3.11+ required (found ${PY_VER})."
  info "Installing Python 3.12 via deadsnakes PPA..."
  sudo add-apt-repository -y ppa:deadsnakes/ppa > /dev/null
  sudo apt-get update -qq
  sudo apt-get install -y -qq python3.12 python3.12-venv python3.12-dev > /dev/null
  PYTHON_BIN="python3.12"
}
PYTHON_BIN="${PYTHON_BIN:-python3}"

# ── 3. Create directories ─────────────────────────────────────────────────────
info "Creating NGINA directories..."
mkdir -p "${NGINA_HOME}"/{firmware,orchestration,dashboard,sounds,nemo-scripts}
mkdir -p "${CONFIG_DIR}" "${LOG_DIR}" "${DESKTOP_DIR}" "${AUTOSTART_DIR}"
mkdir -p "${BIN_DIR}" "${ICON_DIR}"
success "Directories ready."

# ── 4. Install project files ───────────────────────────────────────────────────
info "Installing NGINA to ${NGINA_HOME}..."
cp -r "${SOURCE_DIR}/firmware"      "${NGINA_HOME}/"
cp -r "${SOURCE_DIR}/orchestration" "${NGINA_HOME}/"
cp -r "${SOURCE_DIR}/dashboard"     "${NGINA_HOME}/"
cp -r "${SOURCE_DIR}/tray"          "${NGINA_HOME}/"
cp -r "${SOURCE_DIR}/server.py"     "${NGINA_HOME}/"
cp -r "${SOURCE_DIR}/main.py"       "${NGINA_HOME}/"
touch "${NGINA_HOME}/firmware/__init__.py"
touch "${NGINA_HOME}/orchestration/__init__.py"
for snd in boot alert happy concern ack; do
  [[ -f "${NGINA_HOME}/sounds/${snd}.wav" ]] || touch "${NGINA_HOME}/sounds/${snd}.wav"
done
success "Files installed."

# ── 5. Virtual environment ────────────────────────────────────────────────────
info "Creating Python virtual environment..."
"${PYTHON_BIN}" -m venv "${VENV_DIR}"

info "Installing Python dependencies..."
"${VENV_DIR}/bin/pip" install --upgrade pip --quiet
"${VENV_DIR}/bin/pip" install \
  anthropic flask flask-cors pyttsx3 pyserial smbus2 \
  --quiet
success "Python dependencies installed."

# ── 6. SVG icon (Triskelion) ──────────────────────────────────────────────────
cat > "${ICON_DIR}/ngina.svg" << 'SVGEOF'
<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
  <rect width="64" height="64" rx="14" fill="#080c14"/>
  <circle cx="32" cy="32" r="28" fill="none" stroke="#00c9a7" stroke-width="1.2" opacity="0.4"/>
  <g transform="translate(32,32)">
    <path d="M0,-18 Q9,-9 0,0 Q-9,-9 0,-18Z" fill="#00c9a7" opacity="0.95"/>
    <path d="M0,-18 Q9,-9 0,0 Q-9,-9 0,-18Z" fill="#00c9a7" opacity="0.95" transform="rotate(120)"/>
    <path d="M0,-18 Q9,-9 0,0 Q-9,-9 0,-18Z" fill="#00c9a7" opacity="0.95" transform="rotate(240)"/>
    <circle r="4" fill="#00c9a7"/>
  </g>
</svg>
SVGEOF
# Also copy to hicolor theme so panel icon works
mkdir -p "${HOME}/.local/share/icons/hicolor/scalable/apps"
cp "${ICON_DIR}/ngina.svg" \
   "${HOME}/.local/share/icons/hicolor/scalable/apps/ngina.svg"
gtk-update-icon-cache -f "${HOME}/.local/share/icons/hicolor" 2>/dev/null || true
success "Icon installed."

# ── 7. API key & env config ───────────────────────────────────────────────────
ENV_FILE="${CONFIG_DIR}/ngina.env"
if [[ ! -f "${ENV_FILE}" ]]; then
  info "Collecting configuration..."
  echo ""

  API_KEY=""
  SIMULATE="1"
  if gui_question "Do you have an Anthropic API key?\n\nYou can add it later by editing\n~/.config/ngina/ngina.env"; then
    API_KEY=$(gui_password)
    [[ -n "$API_KEY" ]] && SIMULATE="0"
  fi

  cat > "${ENV_FILE}" << EOF
# NGINA Configuration — Linux Mint
# Edit this file then run: cat > "${ENV_FILE}" << EOF
# NGINA Configuration — Linux Mint
# Edit this file then run: ngina-ctl restart

# Anthropic API key (https://console.anthropic.com)
ANTHROPIC_API_KEY=

# 0=live Claude responses  1=simulated (no key needed)
NGINA_SIMULATE_API=1

# Hardware: 1=real Teksta puppy hardware  0=simulation
NGINA_HARDWARE=0
EOF

ngina-ctl restart

# Anthropic API key (https://console.anthropic.com)
ANTHROPIC_API_KEY=${API_KEY}

# 0=live Claude responses  1=simulated (no key needed)
NGINA_SIMULATE_API=${SIMULATE}

# Hardware: 1=real Teksta puppy hardware  0=simulation
NGINA_HARDWARE=0

# Serial port for physical Teksta
NGINA_SERIAL_PORT=/dev/ttyUSB0

# Local server settings
NGINA_HOST=127.0.0.1
NGINA_PORT=${NGINA_PORT}

# Open browser automatically on start
NGINA_OPEN_BROWSER=1

# Log level: DEBUG  INFO  WARNING  ERROR
NGINA_LOG_LEVEL=INFO

# Habitat name
NGINA_HABITAT_NAME=OASEAS

# Desktop environment (auto-detected: ${DE})
NGINA_DE=${DE}
EOF
  chmod 600 "${ENV_FILE}"
  success "Config saved to ${ENV_FILE}"
else
  warn "Config exists — not overwriting."
fi

# ── 8. Launch script ──────────────────────────────────────────────────────────
LAUNCH="${NGINA_HOME}/launch.sh"
cat > "${LAUNCH}" << LAUNCHEOF
#!/usr/bin/env bash
# NGINA Mint launch script
set -euo pipefail

NGINA_HOME="${NGINA_HOME}"
ENV_FILE="${CONFIG_DIR}/ngina.env"
LOG_DIR="${LOG_DIR}"
VENV="${VENV_DIR}"

[[ -f "\${ENV_FILE}" ]] && set -a && source "\${ENV_FILE}" && set +a
export LOG_DIR="\${LOG_DIR}"
export PYTHONPATH="\${NGINA_HOME}"

PORT="\${NGINA_PORT:-8765}"

# Already running?
if pgrep -f "ngina/server.py" > /dev/null 2>&1; then
  notify-send "NGINA" "Already running — opening dashboard." \
    --icon=ngina --app-name=NGINA --expire-time=4000 2>/dev/null || true
  xdg-open "http://127.0.0.1:\${PORT}" 2>/dev/null || true
  exit 0
fi

cd "\${NGINA_HOME}"
nohup "\${VENV}/bin/python" server.py >> "\${LOG_DIR}/ngina.log" 2>&1 &
echo \$! > "\${LOG_DIR}/ngina.pid"

# Wait up to 15s for server
for i in \$(seq 1 30); do
  curl -sf "http://127.0.0.1:\${PORT}/api/health" > /dev/null 2>&1 && break
  sleep 0.5
done

notify-send "NGINA" "Habitat companion online." \
  --icon=ngina --app-name=NGINA --expire-time=5000 2>/dev/null || true

[[ "\${NGINA_OPEN_BROWSER:-1}" == "1" ]] && \
  xdg-open "http://127.0.0.1:\${PORT}" 2>/dev/null || true

trap 'kill \$(cat "\${LOG_DIR}/ngina.pid" 2>/dev/null) 2>/dev/null; \
      rm -f "\${LOG_DIR}/ngina.pid"' EXIT SIGTERM SIGINT
wait \$(cat "\${LOG_DIR}/ngina.pid" 2>/dev/null)
LAUNCHEOF
chmod +x "${LAUNCH}"
success "Launch script created."

# ── 9. .desktop launcher ──────────────────────────────────────────────────────
info "Creating application launcher..."

# Nemo (Mint's file manager) action categories differ slightly from Nautilus
cat > "${DESKTOP_DIR}/ngina.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=NGINA Habitat Companion
GenericName=AI Habitat Monitor
Comment=OASEAS Habitat AI Orchestrator — crew support and environmental monitoring
Exec=${LAUNCH}
Icon=ngina
Terminal=false
Categories=Science;Monitor;Utility;
Keywords=AI;habitat;OASEAS;NGINA;monitoring;environment;sensor;
StartupNotify=true
Actions=OpenDashboard;StopNGINA;ViewLogs;SensorTest;

[Desktop Action OpenDashboard]
Name=Open Dashboard
Exec=xdg-open http://127.0.0.1:${NGINA_PORT}
Icon=web-browser

[Desktop Action StopNGINA]
Name=Stop NGINA
Exec=${BIN_DIR}/ngina-ctl stop
Icon=process-stop

[Desktop Action ViewLogs]
Name=View Logs
Exec=xterm -e "tail -f ${LOG_DIR}/ngina.log"
Icon=text-x-log

[Desktop Action SensorTest]
Name=Sensor Readings
Exec=xterm -hold -e "${BIN_DIR}/ngina-ctl sensor-test"
Icon=utilities-system-monitor
EOF
chmod +x "${DESKTOP_DIR}/ngina.desktop"
update-desktop-database "${DESKTOP_DIR}" 2>/dev/null || true
success ".desktop launcher created."

# ── 10. Nemo right-click scripts ─────────────────────────────────────────────
NEMO_SCRIPTS="${HOME}/.local/share/nemo/scripts"
mkdir -p "${NEMO_SCRIPTS}"
cp "${SOURCE_DIR}/nemo/"*.sh "${NEMO_SCRIPTS}/" 2>/dev/null || true
chmod +x "${NEMO_SCRIPTS}/"*.sh 2>/dev/null || true
success "Nemo scripts installed (right-click in Nemo file manager)."

# ── 11. Autostart (NGINA service) ─────────────────────────────────────────────
info "Creating autostart entries..."
cat > "${AUTOSTART_DIR}/ngina.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=NGINA Habitat Companion
Comment=Start NGINA AI orchestrator at login
Exec=${LAUNCH}
Icon=ngina
Terminal=false
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
X-GNOME-Autostart-Delay=6
X-MATE-Autostart-enabled=true
X-MATE-Autostart-Delay=6
EOF

# ── 12. Tray applet autostart ─────────────────────────────────────────────────
TRAY_SCRIPT="${NGINA_HOME}/tray/ngina_tray.py"
cat > "${AUTOSTART_DIR}/ngina-tray.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=NGINA Tray
Comment=NGINA system tray applet
Exec=${VENV_DIR}/bin/python ${TRAY_SCRIPT}
Icon=ngina
Terminal=false
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
X-GNOME-Autostart-Delay=10
X-MATE-Autostart-enabled=true
X-MATE-Autostart-Delay=10
EOF
success "Autostart entries created."

# ── 13. Cinnamon-specific: desklet hint ───────────────────────────────────────
if [[ "$DE" == "cinnamon" ]]; then
  info "Cinnamon detected — adding panel applet note to config..."
  cat >> "${ENV_FILE}" << 'EOF'

# Cinnamon: the tray icon uses python3-xapp StatusIcon.
# If you prefer a Cinnamon panel widget, see:
# https://cinnamon-spices.linuxmint.com/applets
# The NGINA web dashboard at http://127.0.0.1:8765 is the primary interface.
EOF
fi

# ── 14. MATE-specific: notification area ─────────────────────────────────────
if [[ "$DE" == "mate" ]]; then
  info "MATE detected — ensuring notification area applet is active..."
  # Hint: user may need to add the notification area applet to the MATE panel
  cat >> "${ENV_FILE}" << 'EOF'

# MATE: if the NGINA tray icon is not visible, right-click your panel →
# Add to Panel → Notification Area.
EOF
fi

# ── 15. Xfce-specific: systray ────────────────────────────────────────────────
if [[ "$DE" == "xfce" ]]; then
  info "Xfce detected — checking for systray panel plugin..."
  cat >> "${ENV_FILE}" << 'EOF'

# Xfce: if the NGINA tray icon is not visible, right-click your panel →
# Panel → Add New Items → Status Tray Plugin (or Notification Area).
EOF
fi

# ── 16. ngina-ctl ────────────────────────────────────────────────────────────
info "Installing ngina-ctl to ${BIN_DIR}..."
cp -r "${SOURCE_DIR}/scripts/ngina-ctl-mint" "${BIN_DIR}/ngina-ctl"
chmod +x "${BIN_DIR}/ngina-ctl"

# Ensure ~/.local/bin on PATH
PROFILE_FILE="${HOME}/.bashrc"
if ! grep -q "${BIN_DIR}" "${PROFILE_FILE}" 2>/dev/null; then
  echo "" >> "${PROFILE_FILE}"
  echo "# NGINA" >> "${PROFILE_FILE}"
  echo 'export PATH="${HOME}/.local/bin:${PATH}"' >> "${PROFILE_FILE}"
  warn "Added ~/.local/bin to PATH in ~/.bashrc — open a new terminal or run: source ~/.bashrc"
fi
success "ngina-ctl installed."

# ── 17. Launch offer ──────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${BOLD}  NGINA Linux Mint Installation Complete${RESET}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""
echo -e "  Desktop:      ${CYAN}${DE}${RESET}"
echo -e "  Dashboard:    ${CYAN}http://127.0.0.1:${NGINA_PORT}/${RESET}"
echo -e "  Config:       ${YELLOW}${ENV_FILE}${RESET}"
echo -e "  Logs:         ${YELLOW}${LOG_DIR}/ngina.log${RESET}"
echo -e "  Menu entry:   ${CYAN}Menu → Science → NGINA Habitat Companion${RESET}"
echo ""
echo -e "  ${BOLD}Start now:${RESET}  ${CYAN}ngina-ctl start${RESET}  (or open a new terminal first)"
echo ""

if gui_question "Installation complete!\n\nDashboard: http://127.0.0.1:${NGINA_PORT}\n\nLaunch NGINA now?"; then
  bash "${LAUNCH}" &
  disown
fi
