#!/usr/bin/env bash
# NGINA Nemo Script: Sensor Readings
# Appears in Nemo right-click → Scripts → NGINA → Sensor Readings

NGINA_CTL="${HOME}/.local/bin/ngina-ctl"
PORT="8765"
[[ -f "${HOME}/.config/ngina/ngina.env" ]] && \
  PORT=$(grep "^NGINA_PORT=" "${HOME}/.config/ngina/ngina.env" | cut -d= -f2 || echo "8765")

# Show in a yad dialog for a GUI output
DATA=$(curl -sf "http://127.0.0.1:${PORT}/api/status" 2>/dev/null) || {
  notify-send "NGINA" "NGINA is not running. Start with: ngina-ctl start" \
    --icon=dialog-warning --expire-time=5000
  exit 1
}

OUTPUT=$(echo "$DATA" | python3 -c "
import sys, json
d = json.load(sys.stdin)
s = d.get('sensors', {})
alerts = d.get('alerts', [])
mood = d.get('mood', '—')
lines = [
    f'Temperature : {s.get(\"temperature\",\"—\")} °C',
    f'Humidity    : {s.get(\"humidity\",\"—\")} %RH',
    f'CO₂ Level   : {s.get(\"co2\",\"—\")} ppm',
    f'Oxygen      : {s.get(\"oxygen\",\"—\")} %',
    f'Pressure    : {s.get(\"pressure\",\"—\")} kPa',
    f'Sound Level : {s.get(\"sound\",\"—\")} dB',
    '',
    f'Mood        : {mood}',
]
if alerts:
    lines.append('')
    lines.append(f'⚠  {len(alerts)} alert(s):')
    for a in alerts: lines.append(f'   {a}')
else:
    lines.append('✓  All parameters nominal')
print('\n'.join(lines))
" 2>/dev/null)

if command -v yad &>/dev/null; then
  yad --title="NGINA Sensor Readings" \
      --text="<tt>${OUTPUT}</tt>" \
      --text-align=left \
      --width=360 --height=280 \
      --button="Open Dashboard:0" \
      --button="Close:1" \
      --image=dialog-information 2>/dev/null
  [[ $? -eq 0 ]] && xdg-open "http://127.0.0.1:${PORT}" 2>/dev/null || true
else
  notify-send "NGINA Sensors" "$OUTPUT" --icon=dialog-information --expire-time=8000
fi
