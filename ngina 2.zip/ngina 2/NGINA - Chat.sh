#!/usr/bin/env bash
# NGINA Nemo Script: Chat
# Appears in Nemo right-click → Scripts → NGINA → Chat with NGINA

PORT="8765"
[[ -f "${HOME}/.config/ngina/ngina.env" ]] && \
  PORT=$(grep "^NGINA_PORT=" "${HOME}/.config/ngina/ngina.env" | cut -d= -f2 || echo "8765")

# Get user message
if command -v yad &>/dev/null; then
  MSG=$(yad --entry \
    --title="Chat with NGINA" \
    --text="Speak to NGINA:" \
    --entry-text="Hello NGINA, how is the habitat?" \
    --width=440 2>/dev/null) || exit 0
else
  MSG="Hello NGINA, give me a status report."
fi

[[ -z "$MSG" ]] && exit 0

# Send to API
RESPONSE=$(curl -sf -X POST "http://127.0.0.1:${PORT}/api/chat" \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"${MSG}\"}" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('response','[no response]'))" \
  2>/dev/null) || RESPONSE="NGINA is not responding. Is it running?"

# Show response
if command -v yad &>/dev/null; then
  yad --title="NGINA" \
      --text="<b>You:</b> ${MSG}\n\n<b>NGINA:</b> ${RESPONSE}" \
      --text-align=left \
      --wrap \
      --width=480 --height=220 \
      --button="OK:0" \
      --image="${HOME}/.local/share/icons/ngina/ngina.svg" 2>/dev/null || true
else
  notify-send "NGINA" "${RESPONSE}" --icon=dialog-information --expire-time=8000
fi
