#!/usr/bin/env bash
# NGINA Nemo Script: Start / Open Dashboard
# Appears in Nemo (Mint file manager) right-click → Scripts → NGINA → Start

NGINA_CTL="${HOME}/.local/bin/ngina-ctl"

if [[ -f "$NGINA_CTL" ]]; then
  "$NGINA_CTL" start
else
  notify-send "NGINA" "ngina-ctl not found. Run install-mint.sh first." \
    --icon=dialog-error --expire-time=5000
fi
