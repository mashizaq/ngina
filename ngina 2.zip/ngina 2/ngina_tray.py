#!/usr/bin/env python3
"""
NGINA System Tray — Linux Mint Edition
========================================
Uses python3-xapp XApp.StatusIcon which works natively across all
three Linux Mint desktop environments:
  ✓ Cinnamon — system tray area
  ✓ MATE     — notification area applet
  ✓ Xfce     — status tray plugin

Fallback: GTK3 StatusIcon (deprecated but still functional on Mint 21/22)

Dependencies (installed by install-mint.sh):
  python3-xapp  python3-gi  gir1.2-gtk-3.0

Run:
  ~/.local/ngina/venv/bin/python ~/.local/ngina/tray/ngina_tray.py
"""

import os
import sys
import json
import signal
import subprocess
import threading
import time
from pathlib import Path
from urllib import request as urlrequest
from urllib.error import URLError

# ── Config ────────────────────────────────────────────────────────────────────
CONFIG_FILE = Path.home() / ".config/ngina/ngina.env"
LOG_DIR     = Path.home() / ".local/share/ngina/logs"
NGINA_HOME  = Path.home() / ".local/ngina"

def _load_env() -> dict:
    env = {"NGINA_PORT": "8765", "NGINA_DE": "unknown"}
    if CONFIG_FILE.exists():
        for line in CONFIG_FILE.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()
    return env

ENV  = _load_env()
PORT = ENV.get("NGINA_PORT", "8765")
DE   = ENV.get("NGINA_DE",   "unknown")
BASE = f"http://127.0.0.1:{PORT}"
BIN  = Path.home() / ".local/bin/ngina-ctl"

# ── API ───────────────────────────────────────────────────────────────────────
def api_get(path: str) -> dict | None:
    try:
        with urlrequest.urlopen(f"{BASE}{path}", timeout=3) as r:
            return json.loads(r.read())
    except Exception:
        return None

def api_post(path: str, body: dict = {}) -> dict | None:
    try:
        data = json.dumps(body).encode()
        req  = urlrequest.Request(
            f"{BASE}{path}", data=data,
            headers={"Content-Type": "application/json"},
        )
        with urlrequest.urlopen(req, timeout=6) as r:
            return json.loads(r.read())
    except Exception:
        return None

# ── GTK + XApp ────────────────────────────────────────────────────────────────
try:
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib

    # Try XApp first (best on Mint)
    try:
        gi.require_version("XApp", "1.0")
        from gi.repository import XApp
        HAS_XAPP = True
    except (ImportError, ValueError):
        HAS_XAPP = False

except ImportError:
    print("python3-gi not available — tray disabled.", file=sys.stderr)
    sys.exit(0)

# ── Mood display ──────────────────────────────────────────────────────────────
MOOD_LABEL = {
    "idle":      "Idle",
    "alert":     "⚠ Alert",
    "happy":     "Happy",
    "concerned": "Concerned",
    "focused":   "Focused",
    "patrol":    "On Patrol",
    "sleep":     "Sleep",
}

# ── Tray application ──────────────────────────────────────────────────────────
class NGINATray:

    def __init__(self):
        self._running  = True
        self._is_alive = False
        self._mood     = "idle"
        self._sensors  = {}
        self._alerts   = []

        # Build menu (shared between XApp and fallback)
        self.menu = self._build_menu()

        # Icon path
        icon = str(Path.home() / ".local/share/icons/ngina/ngina.svg")
        if not Path(icon).exists():
            icon = "dialog-information"

        if HAS_XAPP:
            self._init_xapp(icon)
        else:
            self._init_fallback(icon)

        # Poll every 12 seconds
        GLib.timeout_add_seconds(12, self._poll)
        GLib.timeout_add(1500, self._poll)   # initial poll

    # ── XApp StatusIcon (preferred on Mint) ───────────────────────────────────
    def _init_xapp(self, icon: str):
        self.icon = XApp.StatusIcon()
        self.icon.set_icon_name("ngina")
        self.icon.set_tooltip_text("NGINA Habitat Companion")
        self.icon.set_visible(True)
        self.icon.connect("button-press-event", self._on_xapp_click)
        self._xapp = True

    def _on_xapp_click(self, icon, x, y, button, time, panel_pos):
        if button == 1:   # left click → open dashboard
            self._open_dashboard()
        elif button == 3: # right click → menu
            self.menu.popup(None, None, None, None, button, time)

    # ── GTK StatusIcon fallback (Xfce / older setups) ─────────────────────────
    def _init_fallback(self, icon: str):
        self._xapp = False
        self.icon = Gtk.StatusIcon()
        if Path(icon).exists():
            self.icon.set_from_file(icon)
        else:
            self.icon.set_from_icon_name("dialog-information")
        self.icon.set_tooltip_text("NGINA Habitat Companion")
        self.icon.set_visible(True)
        self.icon.connect("activate",     lambda i: self._open_dashboard())
        self.icon.connect("popup-menu",   self._on_fallback_menu)

    def _on_fallback_menu(self, icon, button, time):
        self.menu.popup(None, None, None, None, button, time)

    # ── Menu ──────────────────────────────────────────────────────────────────
    def _build_menu(self) -> Gtk.Menu:
        menu = Gtk.Menu()

        # Status header
        self._mi_status = Gtk.MenuItem(label="NGINA — checking…")
        self._mi_status.set_sensitive(False)
        menu.append(self._mi_status)

        self._mi_mood = Gtk.MenuItem(label="Mood: —")
        self._mi_mood.set_sensitive(False)
        menu.append(self._mi_mood)

        self._mi_sensors = Gtk.MenuItem(label="Sensors: —")
        self._mi_sensors.set_sensitive(False)
        menu.append(self._mi_sensors)

        menu.append(Gtk.SeparatorMenuItem())

        # Open dashboard
        mi = Gtk.MenuItem(label="Open Dashboard")
        mi.connect("activate", lambda _: self._open_dashboard())
        menu.append(mi)

        menu.append(Gtk.SeparatorMenuItem())

        # Puppy commands
        commands = [
            ("Initiate Patrol",    "patrol"),
            ("Morning Briefing",   "briefing"),
            ("Wellbeing Check",    "wellbeing"),
            ("Philosophical Mode", "philosophy"),
            ("Sleep Mode",         "sleep"),
            ("Wake NGINA",         "wake"),
        ]
        for label, action in commands:
            mi = Gtk.MenuItem(label=label)
            mi.connect("activate", lambda _, a=action: self._cmd(a))
            menu.append(mi)

        menu.append(Gtk.SeparatorMenuItem())

        # Toggle service
        self._mi_toggle = Gtk.MenuItem(label="Start NGINA")
        self._mi_toggle.connect("activate", lambda _: self._toggle())
        menu.append(self._mi_toggle)

        # Config
        mi = Gtk.MenuItem(label="Edit Configuration")
        mi.connect("activate", lambda _: self._open_config())
        menu.append(mi)

        # Logs
        mi = Gtk.MenuItem(label="View Logs")
        mi.connect("activate", lambda _: self._open_logs())
        menu.append(mi)

        # Sensor test
        mi = Gtk.MenuItem(label="Sensor Readings")
        mi.connect("activate", lambda _: self._sensor_test())
        menu.append(mi)

        menu.append(Gtk.SeparatorMenuItem())

        mi = Gtk.MenuItem(label="Quit Tray")
        mi.connect("activate", lambda _: Gtk.main_quit())
        menu.append(mi)

        menu.show_all()
        return menu

    # ── Poll ──────────────────────────────────────────────────────────────────
    def _poll(self) -> bool:
        threading.Thread(target=self._fetch_and_update, daemon=True).start()
        return True   # keep repeating

    def _fetch_and_update(self):
        health = api_get("/api/health")
        status = api_get("/api/status") if health else None
        GLib.idle_add(self._update_ui, health, status)

    def _update_ui(self, health, status):
        alive = health is not None
        self._is_alive = alive

        if not alive:
            self._mi_status.set_label("● NGINA — offline")
            self._mi_mood.set_label("Run: ngina-ctl start")
            self._mi_sensors.set_label("Sensors: unavailable")
            self._mi_toggle.set_label("▶  Start NGINA")
            if HAS_XAPP:
                self._xapp_set_tooltip("NGINA — offline")
            return

        mood    = health.get("mood", "idle")
        uptime  = health.get("uptime_s", 0)
        sim     = " [sim]" if health.get("simulate_api") else ""
        h_str   = f"{uptime//3600}h {(uptime%3600)//60}m"

        self._mi_status.set_label(f"● NGINA online  {h_str}{sim}")
        self._mi_mood.set_label(f"Mood: {MOOD_LABEL.get(mood, mood)}")
        self._mi_toggle.set_label("■  Stop NGINA")

        tip = f"NGINA — {mood}"
        if status:
            s = status.get("sensors", {})
            a = status.get("alerts",  [])
            sensor_str = (
                f"T {s.get('temperature','—')}°C  "
                f"CO₂ {s.get('co2','—')}ppm  "
                f"O₂ {s.get('oxygen','—')}%"
            )
            if a:
                sensor_str += f"  ⚠ {len(a)}"
            self._mi_sensors.set_label(sensor_str)
            tip = f"NGINA {mood} | {sensor_str}"

        if HAS_XAPP:
            self._xapp_set_tooltip(tip)
        else:
            self.icon.set_tooltip_text(tip)

        return False   # idle_add one-shot

    def _xapp_set_tooltip(self, text: str):
        try: self.icon.set_tooltip_text(text)
        except Exception: pass

    # ── Actions ───────────────────────────────────────────────────────────────
    def _open_dashboard(self):
        subprocess.Popen(["xdg-open", f"http://127.0.0.1:{PORT}"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def _cmd(self, action: str):
        threading.Thread(
            target=api_post, args=(f"/api/puppy/{action}",), daemon=True
        ).start()

    def _toggle(self):
        if self._is_alive:
            subprocess.Popen([str(BIN), "stop"])
        else:
            subprocess.Popen(
                ["bash", str(NGINA_HOME / "launch.sh")],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )

    def _open_config(self):
        cfg = str(CONFIG_FILE)
        # Prefer Mint's default text editors by DE
        editors = {
            "cinnamon": ["xed", "gedit", "kate", "mousepad"],
            "mate":     ["pluma", "gedit", "xed", "mousepad"],
            "xfce":     ["mousepad", "xed", "gedit", "pluma"],
        }
        candidates = editors.get(DE, ["xed", "gedit", "pluma", "mousepad", "nano"])
        for ed in candidates:
            if subprocess.run(["which", ed], capture_output=True).returncode == 0:
                subprocess.Popen([ed, cfg])
                return
        # fallback: terminal nano
        self._run_in_terminal(f"nano {cfg}")

    def _open_logs(self):
        self._run_in_terminal(f"tail -f {LOG_DIR}/ngina.log")

    def _sensor_test(self):
        self._run_in_terminal(f"{BIN} sensor-test; read -p 'Press Enter to close...'")

    def _run_in_terminal(self, cmd: str):
        """Launch a terminal command — tries Mint-common terminals."""
        terminals = {
            "cinnamon": ["xterm", "gnome-terminal", "mate-terminal", "xfce4-terminal"],
            "mate":     ["mate-terminal", "xterm", "xfce4-terminal"],
            "xfce":     ["xfce4-terminal", "xterm", "mate-terminal"],
        }
        candidates = terminals.get(DE, ["xterm", "gnome-terminal", "xfce4-terminal"])
        for term in candidates:
            if subprocess.run(["which", term], capture_output=True).returncode == 0:
                if term in ("gnome-terminal", "mate-terminal", "xfce4-terminal"):
                    subprocess.Popen([term, "--", "bash", "-c", cmd])
                else:
                    subprocess.Popen([term, "-e", f"bash -c '{cmd}'"])
                return

# ── Entry ─────────────────────────────────────────────────────────────────────
def main():
    signal.signal(signal.SIGINT,  lambda *_: Gtk.main_quit())
    signal.signal(signal.SIGTERM, lambda *_: Gtk.main_quit())
    NGINATray()
    Gtk.main()

if __name__ == "__main__":
    main()
