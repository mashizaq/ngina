const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

class TelemetryDatabase {
    constructor(dbPath) {
        // Equivalent to your AppConfig logic
        // If no path is provided, you might want a default like './telemetry.db'
        this.dbPath = dbPath || './telemetry.db';

        // Ensure the directory exists
        const dbDir = path.dirname(this.dbPath);
        if (!fs.existsSync(dbDir)) {
            fs.mkdirSync(dbDir, { recursive: true });
        }

        // Initialize connection
        this.db = new Database(this.dbPath);
        this._createTables();
    }

    _createTables() {
        const query = `
            CREATE TABLE IF NOT EXISTS telemetry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                status TEXT,
                co2 REAL,
                o2 REAL,
                temperature REAL,
                humidity REAL,
                pressure REAL,
                health INTEGER
            )
        `;
        this.db.prepare(query).run();
    }

    insertTelemetry(data) {
        const query = `
            INSERT INTO telemetry (timestamp, status, co2, o2, temperature, humidity, pressure, health)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        const stmt = this.db.prepare(query);
        stmt.run(
            data.timestamp || null,
            data.status || null,
            data.co2 ?? null,
            data.o2 ?? null,
            data.temperature ?? null,
            data.humidity ?? null,
            data.pressure ?? null,
            data.health ?? null
        );
    }

    getRecentTelemetry(limit = 20) {
        const query = `
            SELECT timestamp, status, co2, o2, temperature, humidity, pressure, health
            FROM telemetry
            ORDER BY id DESC
            LIMIT ?
        `;

        const rows = this.db.prepare(query).all(limit);
        
        // better-sqlite3 returns objects automatically if you prefer, 
        // but here it is mapped to match your Python structure:
        return rows.map(row => ({
            timestamp: row.timestamp,
            status: row.status,
            co2: row.co2,
            o2: row.o2,
            temperature: row.temperature,
            humidity: row.humidity,
            pressure: row.pressure,
            health: row.health
        }));
    }

    close() {
        this.db.close();
    }
}

module.exports = TelemetryDatabase;
