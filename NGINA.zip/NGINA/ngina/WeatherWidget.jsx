import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { Globe, Rocket, ArrowRight, RefreshCw } from 'lucide-react';

const solDay = Math.floor((Date.now() - new Date('2026-01-01').getTime()) / (1000 * 60 * 60 * 24)) + 1;

async function fetchWeatherSummary() {
  const result = await base44.integrations.Core.InvokeLLM({
    prompt: `Give me: 1) Current real weather for Nairobi Kenya (temperature_c, condition string), and 2) Mars Sol ${solDay} simulation weather (temp_high_c, dust_storm_risk: low/moderate/high/extreme). Return compact JSON only.`,
    add_context_from_internet: true,
    response_json_schema: {
      type: 'object',
      properties: {
        earth: {
          type: 'object',
          properties: {
            temperature_c: { type: 'number' },
            condition: { type: 'string' },
          },
        },
        mars: {
          type: 'object',
          properties: {
            temp_high_c: { type: 'number' },
            dust_storm_risk: { type: 'string' },
          },
        },
      },
    },
  });
  return result;
}

const riskColor = { low: 'text-chart-2', moderate: 'text-chart-4', high: 'text-destructive', extreme: 'text-destructive' };

export default function WeatherWidget() {
  const { data, isLoading } = useQuery({
    queryKey: ['weather-widget'],
    queryFn: fetchWeatherSummary,
    staleTime: 1000 * 60 * 20,
  });

  return (
    <Card className="p-4 bg-card border-border">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <span>🌍</span> Weather
        </h2>
        <Link to="/weather" className="text-xs text-primary hover:underline flex items-center gap-1">
          Full report <ArrowRight className="w-3 h-3" />
        </Link>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-4">
          <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" />
        </div>
      ) : data ? (
        <div className="grid grid-cols-2 gap-3">
          {/* Earth */}
          <div className="rounded-lg bg-secondary/50 p-3 border border-border/30">
            <div className="flex items-center gap-1.5 mb-1">
              <Globe className="w-3.5 h-3.5 text-chart-2" />
              <span className="text-[10px] text-muted-foreground uppercase font-mono">Nairobi</span>
            </div>
            <p className="text-2xl font-bold font-mono text-chart-2">{data.earth?.temperature_c}°C</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">{data.earth?.condition}</p>
          </div>
          {/* Mars */}
          <div className="rounded-lg bg-secondary/50 p-3 border border-border/30">
            <div className="flex items-center gap-1.5 mb-1">
              <Rocket className="w-3.5 h-3.5 text-primary" />
              <span className="text-[10px] text-muted-foreground uppercase font-mono">Sol {solDay}</span>
            </div>
            <p className="text-2xl font-bold font-mono text-primary">{data.mars?.temp_high_c}°C</p>
            <p className={`text-[10px] mt-0.5 capitalize ${riskColor[data.mars?.dust_storm_risk] || 'text-muted-foreground'}`}>
              Dust: {data.mars?.dust_storm_risk}
            </p>
          </div>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground text-center py-4">Weather unavailable</p>
      )}
    </Card>
  );
}