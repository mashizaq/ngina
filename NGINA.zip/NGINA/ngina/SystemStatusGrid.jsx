import React from 'react';
import { Card } from '@/components/ui/card';
import { Cpu, Droplets, Wind, Zap, Radio, ThermometerSun, ShieldCheck, Wrench } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const systemIcons = {
  life_support: ShieldCheck,
  power: Zap,
  communications: Radio,
  structural: Wrench,
  water: Droplets,
  atmosphere: Wind,
  thermal: ThermometerSun,
};

const statusColors = {
  nominal: 'text-chart-2',
  degraded: 'text-chart-4',
  critical: 'text-destructive',
  offline: 'text-muted-foreground',
};

const statusBg = {
  nominal: 'bg-chart-2/10 border-chart-2/20',
  degraded: 'bg-chart-4/10 border-chart-4/20',
  critical: 'bg-destructive/10 border-destructive/20',
  offline: 'bg-muted/50 border-border',
};

export default function SystemStatusGrid({ systems }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {systems.map((system, i) => {
        const Icon = systemIcons[system.category] || Cpu;
        const color = statusColors[system.status] || 'text-muted-foreground';
        const bg = statusBg[system.status] || 'bg-muted/50 border-border';

        return (
          <motion.div
            key={system.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Card className={cn("p-3 border", bg)}>
              <div className="flex items-center gap-2 mb-2">
                <Icon className={cn("w-4 h-4", color)} />
                <span className="text-xs font-medium text-foreground truncate">{system.name}</span>
              </div>
              <div className="flex items-end justify-between">
                <span className={cn("text-xl font-bold font-mono", color)}>
                  {system.health_percent || 0}%
                </span>
                <span className={cn("text-[10px] font-medium uppercase tracking-wider", color)}>
                  {system.status}
                </span>
              </div>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );