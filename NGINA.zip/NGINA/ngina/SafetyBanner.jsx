import React from 'react';
import { Shield, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

export default function SafetyBanner({ alerts }) {
  const criticalAlerts = alerts.filter(a => a.severity === 'critical' && a.status === 'active');
  const warningAlerts = alerts.filter(a => a.severity === 'warning' && a.status === 'active');

  if (criticalAlerts.length > 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-destructive/15 border border-destructive/30 rounded-xl p-4 flex items-center gap-3"
      >
        <div className="safety-pulse">
          <AlertTriangle className="w-6 h-6 text-destructive" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-destructive">
            {criticalAlerts.length} CRITICAL ALERT{criticalAlerts.length > 1 ? 'S' : ''} — CREW SAFETY COMPROMISED
          </p>
          <p className="text-xs text-destructive/70 mt-0.5">
            {criticalAlerts.map(a => a.title).join(' • ')}
          </p>
        </div>
      </motion.div>
    );
  }

  if (warningAlerts.length > 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-chart-4/15 border border-chart-4/30 rounded-xl p-4 flex items-center gap-3"
      >
        <AlertTriangle className="w-5 h-5 text-chart-4" />
        <div className="flex-1">
          <p className="text-sm font-medium text-chart-4">
            {warningAlerts.length} warning{warningAlerts.length > 1 ? 's' : ''} active
          </p>
          <p className="text-xs text-chart-4/70 mt-0.5">
            {warningAlerts.map(a => a.title).join(' • ')}
          </p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-chart-2/10 border border-chart-2/20 rounded-xl p-4 flex items-center gap-3"
    >
      <CheckCircle2 className="w-5 h-5 text-chart-2" />
      <p className="text-sm font-medium text-chart-2">All systems nominal — Crew safety: GREEN</p>
    </motion.div>
  );
}