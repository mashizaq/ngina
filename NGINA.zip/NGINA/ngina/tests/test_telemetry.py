from desktop.data.telemetry import TelemetryProvider


def test_telemetry_generates_data_and_persists(tmp_path):
    db_path = tmp_path / "eclss.db"
    provider = TelemetryProvider(db_path=str(db_path))

    reading = provider.fetch_and_persist()
    assert "co2" in reading
    assert reading["status"] in {"NOMINAL", "DEGRADED"}

    recent = provider.get_recent_records(limit=5)
    assert isinstance(recent, list)
    assert recent[0]["co2"] == reading["co2"]
