import pytest

from desktop.widgets.status_panel import StatusPanel
from desktop.widgets.control_panel import ControlPanel
from desktop.widgets.alerts_panel import AlertsPanel
from desktop.widgets.history_panel import HistoryPanel


@pytest.mark.qtbot
def test_panels_create(qtbot):
    status_panel = StatusPanel()
    control_panel = ControlPanel()
    alerts_panel = AlertsPanel()
    history_panel = HistoryPanel()

    qtbot.addWidget(status_panel)
    qtbot.addWidget(control_panel)
    qtbot.addWidget(alerts_panel)
    qtbot.addWidget(history_panel)

    assert status_panel is not None
    assert control_panel is not None
    assert alerts_panel is not None
    assert history_panel is not None


@pytest.mark.qtbot
def test_control_signals(qtbot):
    control_panel = ControlPanel()
    called = {'start': False, 'stop': False, 'reset': False}

    control_panel.system_started.connect(lambda: called.update({'start': True}))
    control_panel.system_stopped.connect(lambda: called.update({'stop': True}))
    control_panel.system_reset.connect(lambda: called.update({'reset': True}))

    control_panel.on_start()
    control_panel.on_stop()
    control_panel.on_reset()

    assert called['start'] is True
    assert called['stop'] is True
    assert called['reset'] is True
