import os
import tempfile

from desktop.config import AppConfig


def test_config_read_write(tmp_path):
    config_file = tmp_path / "config.json"
    cfg = AppConfig(str(config_file))
    assert cfg.get("database_path") is not None

    cfg.set("database_path", "app_data/new.db")
    cfg2 = AppConfig(str(config_file))
    assert cfg2.get("database_path") == "app_data/new.db"
