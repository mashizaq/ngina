import os
import tempfile

from desktop.db import TelemetryDatabase


def test_db_insert_and_query(tmp_path):
    db_path = tmp_path / "eclss.db"
    db = TelemetryDatabase(str(db_path))

    sample = {
        "timestamp": "2026-01-01T00:00:00",
        "status": "NOMINAL",
        "co2": 0.04,
        "o2": 20.9,
        "temperature": 22.0,
        "humidity": 40.0,
        "pressure": 101.3,
        "health": 98,
    }
    db.insert_telemetry(sample)
    rows = db.get_recent_telemetry(limit=1)
    assert rows
    assert rows[0]["status"] == "NOMINAL"

