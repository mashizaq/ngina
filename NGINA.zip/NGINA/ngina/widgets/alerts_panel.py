from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QPushButton
from PyQt6.QtCore import Qt, QDateTime
from PyQt6.QtGui import QFont, QColor


class AlertsPanel(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)

        title = QLabel("Alerts & Notifications")
        title_font = QFont()
        title_font.setPointSize(12)
        title_font.setBold(True)
        title.setFont(title_font)
        main_layout.addWidget(title)

        self.alert_list = QListWidget()
        self.alert_list.addItem(QListWidgetItem("[INFO] System initialized successfully"))
        self.alert_list.addItem(QListWidgetItem("[WARN] CO2 slightly elevated"))
        self.alert_list.addItem(QListWidgetItem("[OK] Pressure nominal"))
        main_layout.addWidget(self.alert_list)

        button_layout = QHBoxLayout()
        self.clear_btn = QPushButton("Clear Alerts")
        self.clear_btn.clicked.connect(self.clear_alerts)
        button_layout.addWidget(self.clear_btn)

        self.add_btn = QPushButton("Add Test Alert")
        self.add_btn.clicked.connect(self.add_test_alert)
        button_layout.addWidget(self.add_btn)

        button_layout.addStretch()
        main_layout.addLayout(button_layout)

        self.setLayout(main_layout)

    def clear_alerts(self):
        self.alert_list.clear()

    def add_test_alert(self):
        now = QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss")
        item = QListWidgetItem(f"[TEST] {now} - Test alert generated")
        self.alert_list.addItem(item)

    def add_alert(self, level, message):
        now = QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss")
        item = QListWidgetItem(f"[{level}] {now} - {message}")
        self.alert_list.addItem(item)

    def set_update_status(self, message):
        self.add_alert("UPDATE", message)

