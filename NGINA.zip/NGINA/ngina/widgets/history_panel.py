from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem
from PyQt6.QtGui import QFont

from desktop.data.telemetry import TelemetryProvider


class HistoryPanel(QWidget):
    def __init__(self):
        super().__init__()
        self.telemetry_provider = TelemetryProvider()
        self.init_ui()
        self.load_history()

    def init_ui(self):
        main_layout = QVBoxLayout()

        title = QLabel("Telemetry History")
        title_font = QFont()
        title_font.setPointSize(12)
        title_font.setBold(True)
        title.setFont(title_font)
        main_layout.addWidget(title)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels([
            "Timestamp", "Status", "CO2", "O2", "Temperature", "Humidity", "Pressure", "Health"
        ])

        main_layout.addWidget(self.table)
        self.setLayout(main_layout)

    def load_history(self, limit=50):
        records = self.telemetry_provider.get_recent_records(limit)
        self.table.setRowCount(0)

        for record in records:
            row = self.table.rowCount()
            self.table.insertRow(row)
            for col, key in enumerate(["timestamp", "status", "co2", "o2", "temperature", "humidity", "pressure", "health"]):
                item = QTableWidgetItem(str(record.get(key, "")))
                self.table.setItem(row, col, item)
