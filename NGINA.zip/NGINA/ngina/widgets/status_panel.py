from PyQt6.QtWidgets import QWidget, QGridLayout, QLabel, QProgressBar
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QFont

from desktop.data.telemetry import TelemetryProvider


class StatusPanel(QWidget):
    def __init__(self):
        super().__init__()
        self.telemetry_provider = TelemetryProvider()
        self.init_ui()
        self.setup_timers()

    def init_ui(self):
        layout = QGridLayout()
        layout.setSpacing(15)

        title = QLabel("System Status Dashboard")
        title_font = QFont()
        title_font.setPointSize(12)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title, 0, 0, 1, 4)

        row = 1

        layout.addWidget(QLabel("System Status:"), row, 0)
        self.status_label = QLabel("NOMINAL")
        self.status_label.setStyleSheet("color: green; font-weight: bold;")
        layout.addWidget(self.status_label, row, 1)

        layout.addWidget(QLabel("System Health:"), row, 2)
        self.health_bar = QProgressBar()
        self.health_bar.setValue(95)
        layout.addWidget(self.health_bar, row, 3)

        row += 1

        layout.addWidget(QLabel("CO2 Level:"), row, 0)
        self.co2_label = QLabel("0.04%")
        layout.addWidget(self.co2_label, row, 1)

        layout.addWidget(QLabel("CO2 Status:"), row, 2)
        self.co2_bar = QProgressBar()
        self.co2_bar.setValue(15)
        layout.addWidget(self.co2_bar, row, 3)

        row += 1

        layout.addWidget(QLabel("O2 Level:"), row, 0)
        self.o2_label = QLabel("20.9%")
        layout.addWidget(self.o2_label, row, 1)

        layout.addWidget(QLabel("O2 Status:"), row, 2)
        self.o2_bar = QProgressBar()
        self.o2_bar.setValue(85)
        layout.addWidget(self.o2_bar, row, 3)

        row += 1

        layout.addWidget(QLabel("Temperature:"), row, 0)
        self.temp_label = QLabel("22.5°C")
        layout.addWidget(self.temp_label, row, 1)

        layout.addWidget(QLabel("Temp Status:"), row, 2)
        self.temp_bar = QProgressBar()
        self.temp_bar.setValue(60)
        layout.addWidget(self.temp_bar, row, 3)

        row += 1

        layout.addWidget(QLabel("Humidity:"), row, 0)
        self.humidity_label = QLabel("45%")
        layout.addWidget(self.humidity_label, row, 1)

        layout.addWidget(QLabel("Humidity Status:"), row, 2)
        self.humidity_bar = QProgressBar()
        self.humidity_bar.setValue(45)
        layout.addWidget(self.humidity_bar, row, 3)

        row += 1

        layout.addWidget(QLabel("Pressure:"), row, 0)
        self.pressure_label = QLabel("101.3 kPa")
        layout.addWidget(self.pressure_label, row, 1)

        layout.addWidget(QLabel("Pressure Status:"), row, 2)
        self.pressure_bar = QProgressBar()
        self.pressure_bar.setValue(100)
        layout.addWidget(self.pressure_bar, row, 3)

        layout.setRowStretch(row + 1, 1)
        self.setLayout(layout)

    def setup_timers(self):
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_status)
        self.update_timer.start(1000)

    def update_status(self):
        telemetry = self.telemetry_provider.fetch_and_persist()

        self.status_label.setText(telemetry.get("status", "NOMINAL"))
        color = "green" if telemetry["status"] == "NOMINAL" else "orange"
        self.status_label.setStyleSheet(f"color: {color}; font-weight: bold;")

        self.co2_label.setText(f"{telemetry['co2']*100:.2f}%")
        self.co2_bar.setValue(min(int(telemetry['co2'] * 1000), 100))

        self.o2_label.setText(f"{telemetry['o2']:.1f}%")
        self.o2_bar.setValue(min(int(telemetry['o2'] * 5), 100))

        self.temp_label.setText(f"{telemetry['temperature']:.1f}°C")
        self.temp_bar.setValue(min(int((telemetry['temperature'] - 10) * 5), 100))

        self.humidity_label.setText(f"{telemetry['humidity']:.1f}%")
        self.humidity_bar.setValue(min(int(telemetry['humidity']), 100))

        self.pressure_label.setText(f"{telemetry['pressure']:.1f} kPa")
        self.pressure_bar.setValue(min(int((telemetry['pressure'] - 90) * 10), 100))

        self.health_bar.setValue(min(max(int(telemetry['health']), 0), 100))

