import os
import subprocess
import threading
import sys

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox, QGroupBox
from PyQt6.QtCore import pyqtSignal
from PyQt6.QtGui import QFont


class ControlPanel(QWidget):
    mode_changed = pyqtSignal(str)
    system_started = pyqtSignal()
    system_stopped = pyqtSignal()
    system_reset = pyqtSignal()
    packaging_started = pyqtSignal()
    packaging_success = pyqtSignal(str)
    packaging_failed = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.current_mode = "NORMAL"
        self.system_running = False
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(20)

        title = QLabel("System Control Panel")
        title_font = QFont()
        title_font.setPointSize(12)
        title_font.setBold(True)
        title.setFont(title_font)
        main_layout.addWidget(title)

        mode_group = QGroupBox("Operating Mode")
        mode_layout = QVBoxLayout()

        mode_layout.addWidget(QLabel("Current Mode:"))

        current_mode_layout = QHBoxLayout()
        current_mode_layout.addWidget(QLabel("Status:"))
        self.mode_display = QLabel(self.current_mode)
        mode_display_font = QFont()
        mode_display_font.setPointSize(11)
        mode_display_font.setBold(True)
        self.mode_display.setFont(mode_display_font)
        self.mode_display.setStyleSheet("color: blue;")
        current_mode_layout.addWidget(self.mode_display)
        current_mode_layout.addStretch()
        mode_layout.addLayout(current_mode_layout)

        mode_layout.addWidget(QLabel("Switch Mode:"))
        self.mode_selector = QComboBox()
        self.mode_selector.addItems(["NORMAL", "EMERGENCY", "MAINTENANCE"])
        self.mode_selector.currentTextChanged.connect(self.on_mode_changed)
        mode_layout.addWidget(self.mode_selector)

        mode_group.setLayout(mode_layout)
        main_layout.addWidget(mode_group)

        control_group = QGroupBox("System Control")
        control_layout = QVBoxLayout()

        control_layout.addWidget(QLabel("System Status:"))
        status_layout = QHBoxLayout()
        status_layout.addWidget(QLabel("Running:"))
        self.running_label = QLabel("STOPPED")
        self.running_label.setStyleSheet("color: red; font-weight: bold;")
        status_layout.addWidget(self.running_label)
        status_layout.addStretch()
        control_layout.addLayout(status_layout)

        button_layout = QHBoxLayout()

        self.start_btn = QPushButton("▶ Start System")
        self.start_btn.setMinimumHeight(40)
        self.start_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                border-radius: 5px;
                padding: 5px;
            }
        """)
        self.start_btn.clicked.connect(self.on_start)
        button_layout.addWidget(self.start_btn)

        self.stop_btn = QPushButton("⏹ Stop System")
        self.stop_btn.setMinimumHeight(40)
        self.stop_btn.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                font-weight: bold;
                border-radius: 5px;
                padding: 5px;
            }
        """)
        self.stop_btn.clicked.connect(self.on_stop)
        self.stop_btn.setEnabled(False)
        button_layout.addWidget(self.stop_btn)

        self.reset_btn = QPushButton("🔄 Reset System")
        self.reset_btn.setMinimumHeight(40)
        self.reset_btn.setStyleSheet("""
            QPushButton {
                background-color: #FF9800;
                color: white;
                font-weight: bold;
                border-radius: 5px;
                padding: 5px;
            }
        """)
        self.reset_btn.clicked.connect(self.on_reset)
        button_layout.addWidget(self.reset_btn)

        self.package_btn = QPushButton("📦 Package App")
        self.package_btn.setMinimumHeight(40)
        self.package_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                font-weight: bold;
                border-radius: 5px;
                padding: 5px;
            }
        """)
        self.package_btn.clicked.connect(self.on_package)
        button_layout.addWidget(self.package_btn)

        self.package_status_label = QLabel("")
        self.package_status_label.setStyleSheet("font-size: 11px; color: #555;")
        control_layout.addWidget(self.package_status_label)

        control_layout.addLayout(button_layout)
        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)

        main_layout.addStretch()
        self.setLayout(main_layout)

    def on_mode_changed(self, mode):
        self.current_mode = mode
        self.mode_display.setText(mode)

        if mode == "EMERGENCY":
            self.mode_display.setStyleSheet("color: red; font-weight: bold;")
        elif mode == "MAINTENANCE":
            self.mode_display.setStyleSheet("color: orange; font-weight: bold;")
        else:
            self.mode_display.setStyleSheet("color: blue; font-weight: bold;")

        self.mode_changed.emit(mode)

    def on_start(self):
        self.system_running = True
        self.running_label.setText("RUNNING")
        self.running_label.setStyleSheet("color: green; font-weight: bold;")
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.system_started.emit()

    def on_stop(self):
        self.system_running = False
        self.running_label.setText("STOPPED")
        self.running_label.setStyleSheet("color: red; font-weight: bold;")
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.system_stopped.emit()

    def on_reset(self):
        self.system_reset.emit()

    def on_package(self):
        self.package_status_label.setText("Packaging app... This may take a minute.")
        self.packaging_started.emit()

        def run_packaging():
            try:
                script_path = os.path.join(os.path.dirname(__file__), "..", "build_windows_exe.py")
                script_path = os.path.abspath(script_path)
                subprocess.run([sys.executable, script_path], check=True)
                self.package_status_label.setText("Packaging completed successfully.")
                self.packaging_success.emit("Packaging completed successfully")
            except subprocess.CalledProcessError as exc:
                self.package_status_label.setText(f"Packaging failed: {exc}")
                self.packaging_failed.emit(str(exc))

        threading.Thread(target=run_packaging, daemon=True).start()

