import React from 'react';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

export default function MissionStats({ logs }) {
  const stats = [
    { label: 'Total Tasks', value: logs.length, color: 'text-foreground' },
    { label: 'Pending', value: logs.filter(l => l.status === 'pending').length, color: 'text-chart-4' },
    { label: 'In Progress', value: logs.filter(l => l.status === 'in_progress').length, color: 'text-primary' },
    { label: 'Completed', value: logs.filter(l => l.status === 'completed').length, color: 'text-chart-2' },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.05 }}
        >
          <Card className="p-4 bg-card/50 border-border/50 text-center">
            <p className={cn("text-2xl font-bold font-mono", stat.color)}>{stat.value}</p>
            <p className="text-[11px] text-muted-foreground mt-1">{stat.label}</p>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}