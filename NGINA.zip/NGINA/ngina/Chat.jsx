import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import MessageBubble from '../components/chat/MessageBubble';
import ChatInput from '../components/chat/ChatInput';
import ARIAAvatar from '../components/chat/ARIAAvatar';
import ARIAVideoCall from '../components/chat/ARIAVideoCall';
import { useARIAVoice } from '../components/chat/useARIAVoice';
import { Plus, MessageCircle, Video, Volume2, VolumeX, Command } from 'lucide-react';
import { useVoiceCommands } from '../components/chat/useVoiceCommands';
import VoiceCommandPanel from '../components/chat/VoiceCommandPanel';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { motion, AnimatePresence } from 'framer-motion';
import { motion } from "framer-motion";

export const MyComponent = () => (
  <motion.div 
    initial={{ opacity: 0, y: -20 }} 
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
  >
    Hello! I'm animated.
  </motion.div>
);


// Strip markdown symbols so TTS reads cleanly
function stripMarkdown(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    .replace(/`{1,3}[^`]*`{1,3}/g, '')
    .replace(/#{1,6}\s/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/>\s?/g, '')
    .replace(/\n+/g, '. ')
    .trim();
}

export default function Chat() {
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [videoCallOpen, setVideoCallOpen] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [micActive, setMicActive] = useState(false);
  const [showCommandPanel, setShowCommandPanel] = useState(false);
  const [handsFreeOn, setHandsFreeOn] = useState(false);
  const messagesEndRef = useRef(null);
  const prevMessageCountRef = useRef(0);

  const { speak, stopSpeaking, startListening, stopListening, isSpeaking, isListening } = useARIAVoice();

  useEffect(() => { loadConversations(); }, []);
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  // Auto-read new ARIA messages aloud
  useEffect(() => {
    if (!voiceEnabled || messages.length === 0) return;
    if (messages.length <= prevMessageCountRef.current) {
      prevMessageCountRef.current = messages.length;
      return;
    }
    prevMessageCountRef.current = messages.length;
    const latest = messages[messages.length - 1];
    if (latest?.role === 'assistant' && latest?.content) {
      speak(stripMarkdown(latest.content));
    }
  }, [messages, voiceEnabled, speak]);

  // Subscribe to conversation updates
  useEffect(() => {
    if (!activeConversation) return;
    const unsubscribe = base44.agents.subscribeToConversation(activeConversation.id, (data) => {
      setMessages(data.messages || []);
    });
    return () => unsubscribe();
  }, [activeConversation?.id]);

  const loadConversations = async () => {
    const convos = await base44.agents.listConversations({ agent_name: 'oaseas_sidekick' });
    setConversations(convos);
    if (convos.length > 0) selectConversation(convos[0]);
  };

  const selectConversation = async (convo) => {
    const full = await base44.agents.getConversation(convo.id);
    prevMessageCountRef.current = full.messages?.length || 0;
    setActiveConversation(full);
    setMessages(full.messages || []);
    setShowSidebar(false);
  };

  const createNewChat = async () => {
    const convo = await base44.agents.createConversation({
      agent_name: 'oaseas_sidekick',
      metadata: { name: `Mission Chat ${new Date().toLocaleDateString()}` },
    });
    setConversations(prev => [convo, ...prev]);
    setActiveConversation(convo);
    prevMessageCountRef.current = 0;
    setMessages([]);
    setShowSidebar(false);
  };

  const handleSend = async (content, fileUrls) => {
    let convo = activeConversation;
    if (!convo) {
      convo = await base44.agents.createConversation({
        agent_name: 'oaseas_sidekick',
        metadata: { name: `Mission Chat ${new Date().toLocaleDateString()}` },
      });
      setConversations(prev => [convo, ...prev]);
      setActiveConversation(convo);
    }
    stopSpeaking();
    setIsLoading(true);
    const msgPayload = { role: 'user', content };
    if (fileUrls) msgPayload.file_urls = fileUrls;
    await base44.agents.addMessage(convo, msgPayload);
    setIsLoading(false);
  };

  // Voice command system
  const { COMMANDS, activeCommand, commandMode, lastTriggered, startCommandMode, stopCommandMode } = useVoiceCommands({
    onCommand: (prompt) => handleSend(prompt),
    onWake: (transcript) => handleSend(transcript),
    speak,
    startListening,
    stopListening,
  });

  const handleHandsFreeToggle = useCallback(() => {
    if (handsFreeOn) {
      stopCommandMode();
      setHandsFreeOn(false);
      speak("Hands-free mode off.");
    } else {
      setHandsFreeOn(true);
      setShowCommandPanel(true);
      speak("Hands-free mode activated. Say Hey ARIA or a command to begin.");
      startCommandMode();
    }
  }, [handsFreeOn, startCommandMode, stopCommandMode, speak]);

  // Mic toggle for voice input
  const handleMicToggle = useCallback(() => {
    if (micActive) {
      stopListening();
      setMicActive(false);
    } else {
      setMicActive(true);
      stopSpeaking();
      startListening(
        (transcript) => {
          setMicActive(false);
          handleSend(transcript);
        },
        () => setMicActive(false)
      );
    }
  }, [micActive, startListening, stopListening, stopSpeaking]);

  return (
    <>
      {/* Voice Command Panel */}
      <AnimatePresence>
        {showCommandPanel && (
          <VoiceCommandPanel
            commands={COMMANDS}
            activeCommand={activeCommand}
            commandMode={commandMode}
            isHandsFreeOn={handsFreeOn}
            lastTriggered={lastTriggered}
            onToggle={handleHandsFreeToggle}
          />
        )}
      </AnimatePresence>

      {/* Video call overlay */}
      <AnimatePresence>
        {videoCallOpen && (
          <ARIAVideoCall
            isSpeaking={isSpeaking}
            isListening={isListening || micActive}
            isOpen={videoCallOpen}
            onClose={() => setVideoCallOpen(false)}
            onMicToggle={handleMicToggle}
            micActive={micActive}
          />
        )}
      </AnimatePresence>

      <div className="h-screen flex flex-col bg-background">
        {/* Header */}
        <div className="h-14 border-b border-border bg-card/80 backdrop-blur-sm flex items-center justify-between px-4 flex-shrink-0">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSidebar(!showSidebar)}
              className="text-muted-foreground"
            >
              <MessageCircle className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-2.5">
              {/* Mini avatar in header */}
              <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                <ARIAAvatar isSpeaking={isSpeaking} isListening={micActive} size="sm" />
              </div>
              <div>
                <p className="text-sm font-semibold leading-tight">ARIA</p>
                <p className="text-[10px] text-muted-foreground leading-tight">
                  {isSpeaking ? '🔊 Speaking...' : micActive ? '🎙️ Listening...' : 'Autonomous AI Sidekick'}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Voice commands / hands-free */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowCommandPanel(v => !v)}
              className={showCommandPanel ? 'text-primary' : 'text-muted-foreground'}
              title="Voice Command Panel"
            >
              <Command className="w-4 h-4" />
            </Button>
            {/* Voice on/off */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => { setVoiceEnabled(v => !v); if (isSpeaking) stopSpeaking(); }}
              className={voiceEnabled ? 'text-primary' : 'text-muted-foreground'}
              title={voiceEnabled ? 'Mute ARIA' : 'Unmute ARIA'}
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </Button>
            {/* Video call */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setVideoCallOpen(true)}
              className="text-muted-foreground hover:text-primary"
              title="Start video call with ARIA"
            >
              <Video className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={createNewChat} className="text-primary">
              <Plus className="w-4 h-4 mr-1" /> New
            </Button>
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden relative">
          {/* Conversations Sidebar */}
          <AnimatePresence>
            {showSidebar && (
              <motion.div
                initial={{ x: -260, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -260, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="w-64 border-r border-border bg-card flex-shrink-0 overflow-y-auto absolute md:relative z-10 h-full"
              >
                <div className="p-3 space-y-1">
                  {conversations.map((convo) => (
                    <button
                      key={convo.id}
                      onClick={() => selectConversation(convo)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                        activeConversation?.id === convo.id
                          ? 'bg-primary/15 text-primary'
                          : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                      }`}
                    >
                      <p className="truncate font-medium">{convo.metadata?.name || 'Chat'}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {new Date(convo.created_date).toLocaleDateString()}
                      </p>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Messages */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScrollArea className="flex-1 p-4">
              <div className="max-w-3xl mx-auto space-y-4 pb-4">
                {messages.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    {/* Big avatar on welcome screen */}
                    <motion.div
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.5 }}
                      className="mb-8"
                    >
                      <ARIAAvatar isSpeaking={false} isListening={false} size="lg" />
                    </motion.div>
                    <h2 className="text-xl font-bold mb-2">Hey there, crew member!</h2>
                    <p className="text-sm text-muted-foreground max-w-md mb-2">
                      I'm ARIA — your AI sidekick for the OASEAS habitat. Talk to me by voice 🎙️, start a video call 📹, or type below.
                    </p>
                    <div className="flex items-center gap-3 mb-6">
                      <Button
                        size="sm"
                        onClick={handleMicToggle}
                        className={`gap-2 ${micActive ? 'bg-destructive hover:bg-destructive/90' : 'bg-primary hover:bg-primary/90'}`}
                      >
                        {micActive ? '⏹ Stop' : '🎙️ Speak to ARIA'}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setVideoCallOpen(true)}
                        className="gap-2 border-primary/40 text-primary"
                      >
                        <Video className="w-4 h-4" /> Video Call
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-md">
                      {[
                        "What's the crew safety status?",
                        "Help me plan today's EVA",
                        "Give me a motivation boost",
                        "Run habitat diagnostics"
                      ].map((prompt) => (
                        <button
                          key={prompt}
                          onClick={() => handleSend(prompt)}
                          className="px-4 py-2.5 rounded-xl border border-border bg-card/50 text-sm text-left hover:bg-secondary hover:border-primary/30 transition-all"
                        >
                          {prompt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {messages.map((msg, i) => (
                  <MessageBubble key={i} message={msg} />
                ))}

                {isLoading && messages[messages.length - 1]?.role === 'user' && (
                  <div className="flex gap-3">
                    <div className="h-8 w-8 rounded-full overflow-hidden flex-shrink-0">
                      <ARIAAvatar isSpeaking={false} isListening size="sm" />
                    </div>
                    <div className="bg-card border border-border rounded-2xl rounded-bl-md px-4 py-3">
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Chat input — extended with mic button */}
            <ChatInput onSend={handleSend} isLoading={isLoading} onMicToggle={handleMicToggle} micActive={micActive} />
          </div>
        </div>
      </div>
    </>
  );
}