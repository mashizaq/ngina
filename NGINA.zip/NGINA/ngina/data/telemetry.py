import random
from datetime import datetime

from desktop.db import TelemetryDatabase
from desktop.config import AppConfig


class TelemetryProvider:
    def __init__(self, db_path=None):
        self.config = AppConfig()
        self.db = TelemetryDatabase(db_path=db_path or self.config.get("database_path"))

    def get_current_readings(self):
        return {
            "co2": round(random.uniform(0.03, 0.08), 4),
            "o2": round(random.uniform(19.5, 21.5), 2),
            "temperature": round(random.uniform(18.0, 26.0), 1),
            "humidity": round(random.uniform(30.0, 60.0), 1),
            "pressure": round(random.uniform(99.0, 103.0), 1),
            "health": random.randint(70, 100),
            "timestamp": datetime.utcnow().isoformat(),
            "status": "NOMINAL",
        }

    def fetch_and_persist(self):
        data = self.get_current_readings()
        if data["co2"] > 0.06 or data["temperature"] > 25.0:
            data["status"] = "DEGRADED"
        self.db.insert_telemetry(data)
        return data

    def get_recent_records(self, limit=20):
        return self.db.get_recent_telemetry(limit)
