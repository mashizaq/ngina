import random
from desktop.config import AppConfig
from .base import SensorBase


class SerialSensor(SensorBase):
    def __init__(self):
        self.cfg = AppConfig()
        self.port = self.cfg.get('serial_port', 'COM3')
        self.baud = self.cfg.get('serial_baud', 9600)

    def get_current_readings(self):
        try:
            import serial
            ser = serial.Serial(self.port, self.baud, timeout=1)
            raw = ser.readline().decode('utf-8').strip()
            ser.close()
            if raw:
                parts = raw.split(',')
                if len(parts) >= 6:
                    return {
                        'co2': float(parts[0]),
                        'o2': float(parts[1]),
                        'temperature': float(parts[2]),
                        'humidity': float(parts[3]),
                        'pressure': float(parts[4]),
                        'health': int(parts[5]),
                    }
        except Exception:
            pass

        return {
            'co2': round(random.uniform(0.03, 0.08), 4),
            'o2': round(random.uniform(19.5, 21.5), 2),
            'temperature': round(random.uniform(18.0, 26.0), 1),
            'humidity': round(random.uniform(30.0, 60.0), 1),
            'pressure': round(random.uniform(99.0, 103.0), 1),
            'health': random.randint(70, 100),
        }
