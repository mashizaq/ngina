class SensorBase:
    def get_current_readings(self):
        raise NotImplementedError("Must implement get_current_readings")
