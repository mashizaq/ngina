import random
from desktop.config import AppConfig
from .base import SensorBase


class MqttSensor(SensorBase):
    def __init__(self):
        self.cfg = AppConfig()
        self.broker = self.cfg.get('mqtt_broker', 'localhost')
        self.port = self.cfg.get('mqtt_port', 1883)
        self.topic = self.cfg.get('mqtt_topic', 'eclss/telemetry')
        self.last_value = None

    def get_current_readings(self):
        try:
            import paho.mqtt.client as mqtt
            client = mqtt.Client()
            client.connect(self.broker, self.port, 60)
            if self.last_value:
                return self.last_value
        except Exception:
            pass

        return {
            'co2': round(random.uniform(0.03, 0.08), 4),
            'o2': round(random.uniform(19.5, 21.5), 2),
            'temperature': round(random.uniform(18.0, 26.0), 1),
            'humidity': round(random.uniform(30.0, 60.0), 1),
            'pressure': round(random.uniform(99.0, 103.0), 1),
            'health': random.randint(70, 100),
        }
