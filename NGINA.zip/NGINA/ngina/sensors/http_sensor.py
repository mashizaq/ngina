import random
from desktop.config import AppConfig
from .base import SensorBase


class HttpSensor(SensorBase):
    def __init__(self):
        self.cfg = AppConfig()
        self.url = self.cfg.get('http_sensor_url', 'http://localhost:8000/api/telemetry')

    def get_current_readings(self):
        try:
            import requests
            resp = requests.get(self.url, timeout=2)
            resp.raise_for_status()
            data = resp.json()
            return {
                'co2': float(data.get('co2', 0.04)),
                'o2': float(data.get('o2', 20.9)),
                'temperature': float(data.get('temperature', 22.0)),
                'humidity': float(data.get('humidity', 45.0)),
                'pressure': float(data.get('pressure', 101.3)),
                'health': int(data.get('health', 95)),
            }
        except Exception:
            return {
                'co2': round(random.uniform(0.03, 0.08), 4),
                'o2': round(random.uniform(19.5, 21.5), 2),
                'temperature': round(random.uniform(18.0, 26.0), 1),
                'humidity': round(random.uniform(30.0, 60.0), 1),
                'pressure': round(random.uniform(99.0, 103.0), 1),
                'health': random.randint(70, 100),
            }
