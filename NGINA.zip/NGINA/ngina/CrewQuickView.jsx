import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, Moon, Brain } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';
import { motion } from "framer-motion";

export const MyComponent = () => (
  <motion.div 
    initial={{ opacity: 0, y: -20 }} 
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
  >
    Hello! I'm animated.
  </motion.div>
);


const statusColors = {
  active: 'bg-chart-2/20 text-chart-2 border-chart-2/30',
  resting: 'bg-chart-3/20 text-chart-3 border-chart-3/30',
  eva: 'bg-primary/20 text-primary border-primary/30',
  medical: 'bg-destructive/20 text-destructive border-destructive/30',
  offline: 'bg-muted text-muted-foreground border-border',
};

export default function CrewQuickView({ crew }) {
  return (
    <div className="space-y-2">
      {crew.map((member, i) => (
        <motion.div
          key={member.id}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: i * 0.05 }}
        >
          <Card className="p-3 bg-card/50 border-border/50 hover:bg-card transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs font-bold text-foreground">
                  {member.name?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </div>
                <div>
                  <p className="text-sm font-medium">{member.name}</p>
                  <p className="text-[10px] text-muted-foreground capitalize">{member.role?.replace('_', ' ')}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1" title="Health">
                  <Heart className="w-3 h-3 text-destructive" />
                  <span className="text-xs font-mono">{member.health_score || '—'}</span>
                </div>
                <div className="flex items-center gap-1" title="Stress">
                  <Brain className="w-3 h-3 text-primary" />
                  <span className="text-xs font-mono">{member.stress_level || '—'}</span>
                </div>
                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0", statusColors[member.status])}>
                  {member.status}
                </Badge>
              </div>
            </div>
          </Card>
        </motion.div>
      ))}
      {crew.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-6">No crew members registered</p>
      )}
    </div>
  );
}